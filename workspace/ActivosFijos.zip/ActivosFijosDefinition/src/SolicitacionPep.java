/**
 * 
 */


/**
 * @author viniciussantos
 *
 */
 


public class SolicitacionPep {

	Boolean portalCliente;
	Boolean esProyectosEspeciales;
	Boolean pepBlqueada;
	ComponentesPep[] componentePep;	

	public Boolean getPortalCliente() {
		return portalCliente;
	}

	public void setPortalCliente(Boolean portalCliente) {
		this.portalCliente = portalCliente;
	}

	public Boolean getEsProyectosEspeciales() {
		return esProyectosEspeciales;
	}

	public void setEsProyectosEspeciales(Boolean esProyectosEspeciales) {
		this.esProyectosEspeciales = esProyectosEspeciales;
	}

	public Boolean getPepBlqueada() {
		return pepBlqueada;
	}

	public void setPepBlqueada(Boolean pepBlqueada) {
		this.pepBlqueada = pepBlqueada;
	}

	public ComponentesPep[] getComponentePep() {
		return componentePep;
	}

	public void setComponentePep(ComponentesPep[] componentePep) {
		this.componentePep = componentePep;
	}


	
}
